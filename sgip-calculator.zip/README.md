# SGIP Eligibility & Rebate Calculator

Modular front-end + live back-end.

See public/ for UI, and server/ for incentive scraping API.